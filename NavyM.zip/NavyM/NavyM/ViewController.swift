//
//  ViewController.swift
//  NavyM
//
//  Created by Mutukula,Shiva Kumar on 2/27/18.
//  Copyright © 2018 Mutukula,Shiva Kumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBOutlet weak var NameTF: UITextField!
    @IBOutlet weak var BaseTF: UITextField!
    @IBOutlet weak var CitiesTF: UITextField!
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "AddAirline"){
        
        let name = NameTF.text!
        let base = BaseTF.text!
        let cities = CitiesTF.text!
        let allCities = cities.components(separatedBy: ",")
        let airline = Airline(name: name, profits: 10.5, homebase: base, numEmployees: 15, citiesFlown: allCities)
        
        FAA.addNewAirline(airline)
    }
        if segue.identifier == "CancelAdding"{
            
        }
    }


}

